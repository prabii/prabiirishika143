// 霸都丶傲天 2019年12月24日

var config = {
    // 句子的长度可以任意， 你可以写十句话， 二十句话都可以
    // 每句话尽量不要超过15个字,不然展示效果可能不太好
    texts: [
        "Happy Birthday", 
        "Rishika",
        "i love u",
        "Wish you Many more returns of the day"
    ],
    wish: "Wish you Many more returns of the day",  //这里,每句话结尾的最后一个逗号必须是英文的哦!! 很重要哦!!
    // 时间的格式很重要哦，一定要是下面这个格式!!
    // 年年年年-月月-日日 时时:分分:秒秒
    time: "2023-09-07 0:0:0",    //这里,每句话结尾的最后一个逗号必须是英文的哦!! 很重要哦!!
};
